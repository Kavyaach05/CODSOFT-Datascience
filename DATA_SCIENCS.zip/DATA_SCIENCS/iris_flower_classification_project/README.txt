IRIS FLOWER CLASSIFICATION PROJECT

Steps:

1. Put 'IRIS.csv' inside this folder.
2. Install requirements:
   pip install -r requirements.txt

3. Train Model:
   python train_model.py

4. Run Web App:
   python app.py

Open browser:
http://127.0.0.1:5000
