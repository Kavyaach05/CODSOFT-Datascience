TITANIC SURVIVAL PREDICTION PROJECT

Steps to run:
1. Place your Titanic-Dataset.csv inside this folder.
2. Install requirements:
   pip install -r requirements.txt
3. Run:
   python train_model.py
